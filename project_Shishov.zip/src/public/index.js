import '@babel/polyfill'
import appMain from './js/main'
import './css/style.css'

const app = new Vue(appMain);